﻿//Somente declaramos a variável como inteira e não atribuimos valor 
int numl;

//Declarando uma variável do tipo inteira e atribuimos o valor 5
int num2 = 5;

//Declarando uma variável do tipo string
string nomeAluno;

//variável do tipo lógico (verdadeiro ou falso)
bool resultado = true;

//variável do tipo valor com casas decimais - para valores mais preciosos
double coordenada = 1.80;

//variável do tipo decimal - mais usada para valor monetário
decimal valor = 1.80M;